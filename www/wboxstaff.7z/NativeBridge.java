package com.inplusweb.wboxstaff;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;

import java.net.URLDecoder;

/**
 * Created by MYM on 2015-09-11.
 * 웹뷰와 네이티브 브릿지 클래스
 */
public class NativeBridge {

    // init
    private static final String TAG = "NativeBridge";
    private static Context mContext;
    private static WebView mWebview;
    private static CustomDialog mCustomDialog;

    /**
     * 네이티브 기능 호출
     * @param url
     */
    public static void run(Context context, WebView webview, String url) {

        mContext = context;
        mWebview = webview;

        String[] params = url.replace("native://", "").split("/");
        String mode = params[0];

        Log.d(TAG, "mode : " + mode);
        if (mode == null || mode.equals("")) {
            mCustomDialog = new CustomDialog(mContext);
            mCustomDialog.setTitle("알림");
            mCustomDialog.setContent("비정상적인 호출입니다.");

            mCustomDialog.setPositiveButton("확인",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.show();
        }
        else if(mode.equals("showProgressbar")) {
            // 프로그레스바 출력
            CommonUtilities.showProgressbar(mContext);
        }
        else if(mode.equals("hideProgressbar")) {
            // 프로그레스바 숨김
            CommonUtilities.hideProgressbar(mContext);
        }
        else if(mode.equals("initJoin")) {
            // 회원가입 초기화
            initJoin();
        }
        else if(mode.equals("initLogin")) {
            // 로그인 초기화
            initLogin();
        } else if(mode.equals("storeMemberId")) {
            // 회원 아이디 저장
            storeMemberId(params);
        } else if(mode.equals("getGpsInfo")) {
            // GPS 정보 추출
            getGpsInfo(params);
        }
        else if(mode.equals("moveConfigGps")) {
            // GPS 환경설정 이동
            CommonUtilities.moveConfigGps(mContext);
        }
        else if (mode.equals("openFileChooser")) {
            // 파일선택창 실행
            openFileChooser(params);
        }
        else if (mode.equals("storeFlagUsePush")) {
            // 푸시 사용 여부 저장
            storeFlagUsePush(params);
        } else if(mode.equals("exitApp")) {
            // 어플 종료
            ((Activity)mContext).finish();
        } else if(mode.equals("confirmExit")) {
            // 종료 여부
            confirmExit(params);
        }
        else if(mode.equals("shareBySend")) {
            // 전송을 통한 공유하기
            shareBySend(params);
        }
        else if(mode.equals("submitPortfolioFromApp")) {
            // 앱을 통해서 포트폴리오 폼 전송 호출
            CommonUtilities.showProgressbar(mContext);
            MainActivity.callJavascript("submitPortfolioFromApp()");
        }
    }

    /**
     * 회원가입 폼 초기화
     */
    private static void initJoin() {
        // 디바이스 os
        String deviceOs = "android";

        // 디바이스 regId
        String regId = RegistrationIdManager.getRegistrationId();

        // 휴대폰 번호
        String phoneNo = CommonUtilities.getPhoneNo(mContext);

        // return
        MainActivity.callJavascript("initJoin('" + deviceOs + "', '" + regId + "', '" + phoneNo + "')");
    }

    /**
     * 로그인 폼 초기화
     */
    private static void initLogin() {
        // 디바이스 os
        String deviceOs = "android";

        // 디바이스 regId
        String regId = RegistrationIdManager.getRegistrationId();

        // 휴대폰 번호
        String phoneNo = CommonUtilities.getPhoneNo(mContext);

        // return
        MainActivity.callJavascript("initLogin('" + deviceOs + "', '" + regId + "', '" + phoneNo + "')");
    }

    /**
     * 회원 아이디 저장
     * @param params
     */
    private static void storeMemberId(String[] params) {
        String memberId = "";
        String returnUrl = "";
        if(params.length > 1) {
            memberId = params[1];
        }
        if(params.length > 2) {
            returnUrl = params[2];
            returnUrl = URLDecoder.decode(returnUrl);
        }

        CommonUtilities.storeMemberId(mContext, memberId);
        if(returnUrl != null && !returnUrl.equals("")) {
            MainActivity.callJavascript("location.replace('" + returnUrl + "')");
        }
    }

    /**
     * GPS 정보 조회
     * @param params
     */
    private static void getGpsInfo(String[] params) {

        LocationManager locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);

        boolean isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        Log.d(TAG, "isGpsEnabled : " + isGpsEnabled);
        Log.d(TAG, "isNetworkEnabled : " + isNetworkEnabled);

        if(!isGpsEnabled && !isNetworkEnabled) {
            // 설정이 해제되어 있을 때
            mCustomDialog = new CustomDialog(mContext);
            mCustomDialog.setTitle("위치정보 설정 안내");
            mCustomDialog.setContent("위치정보를 사용할 수 없습니다.\n환경설정에서 위치 서비스를 활성화해주세요.");

            mCustomDialog.setPositiveButton("설정하기",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            CommonUtilities.moveConfigGps(mContext);
                        }
                    });

            mCustomDialog.setNegativeButton("닫기",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.show();
        }
        else {
            long minDistance = 10;
            long minTime = 1000 * 60 * 1;
            double lat;
            double lng;

            Location location = null;
            LocationListener locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            };

            if(isGpsEnabled) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        minTime,
                        minDistance,
                        locationListener
                );

                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }

            if(location == null && isNetworkEnabled) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        minTime,
                        minDistance,
                        locationListener
                );

                location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }

            if(location != null) {
                lat = location.getLatitude();
                lng = location.getLongitude();
                Log.d(TAG, "Location : " + lat + "," + lng);

                MainActivity.callJavascript("getDongByGps('" + lat + "', '" + lng + "')");
            }
            else {
                mCustomDialog = new CustomDialog(mContext);
                mCustomDialog.setTitle("알림");
                mCustomDialog.setContent("위치정보를 구할 수 없습니다.");

                mCustomDialog.setPositiveButton("확인",
                        new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                mCustomDialog.dismiss();
                            }
                        });

                mCustomDialog.show();
            }

            locationManager.removeUpdates(locationListener);
        }
    }

    /**
     * 파일 선택창 열기
     * @param params
     */
    private static void openFileChooser(String[] params) {
        String requestCode = "";
        if(params.length > 1) {
            requestCode = params[1];
            CommonUtilities.openFileChooser(mContext, requestCode);
        }

        if(params.length > 2) {
            MainActivity.pf_id = params[2];
            MainActivity.photoId = params[3];
            Log.d(TAG, "pf_id : " + MainActivity.pf_id + " requestCode : "+requestCode);
        }
    }


    /**
     * 푸시 사용 여부 저장
     * @param params
     */
    private static void storeFlagUsePush(String[] params) {
        String flagUsePush = "";
        if(params.length > 1) {
            flagUsePush = params[1];
        }

        CommonUtilities.storeFlagUsePush(mContext, flagUsePush);
    }

    /**
     * 어플 종료 여부
     * @param params
     */
    private static void confirmExit(String[] params) {
        MainActivity.backPressCloseHandler.onBackPressed();
    }

    /**
     * 전송을 통한 공유
     * @param params
     */
    private static void shareBySend(String[]  params) {
        String send_info = "";
        if(params.length > 1) {
            send_info = params[1];
            send_info = URLDecoder.decode(send_info);
        }

        CommonUtilities.shareBySend(mContext, send_info);
    }
}
