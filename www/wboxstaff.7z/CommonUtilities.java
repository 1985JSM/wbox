package com.inplusweb.wboxstaff;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.display.DisplayManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.ProgressBar;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
/*import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;*/
import com.loopj.android.http.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;

import cz.msebera.android.httpclient.Header;

/**
 * Created by MYM on 2015-09-08.
 * 공통 사용 유틸리티 클래스
 */
public class CommonUtilities {

    // init
    private static final String TAG = "CommonUtilities";
    public final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    public static int sdkInt = Build.VERSION.SDK_INT;
    private final static String DIRECTORY_PATH = Environment.getExternalStorageDirectory() + File.separator + "upload";

    public static final String MEMBER_ID = "memberId";
    public static final String FLAG_USE_PUSH = "flag_use_push";
    public static final String COUNT_RUN = "cntRun";

    private static CustomDialog mCustomDialog;

    /**
     * 프로그레스바 출력
     * @param context
     */
    public static void showProgressbar(Context context) {

        MainActivity.progressbarMain = (ProgressBar) ((MainActivity) context).findViewById(R.id.progressbar_main);
        MainActivity.progressbarMain.setVisibility(View.VISIBLE);
    }

    /**
     * 프로그레스바 숨김
     * @param context
     */
    public static void hideProgressbar(Context context) {
        MainActivity.progressbarMain = (ProgressBar) ((MainActivity) context).findViewById(R.id.progressbar_main);
        MainActivity.progressbarMain.setVisibility(View.INVISIBLE);
    }

    /**
     * 플레이서비스 사용 검사
     * @param activity
     * @return
     */
    public static boolean checkPlayServices(Activity activity){
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(activity);
        if(resultCode != ConnectionResult.SUCCESS) {
            if(GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, activity, PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.i(TAG, "This device is not supported.");
                activity.finish();
            }
            return false;
        }
        return true;
    }

    /**
     * 어플 버전 체크
     * @param context
     * @return
     */
    public static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException("Could not get package name: " + e);
        }
    }

    /**
     * 존재하는 어플(패키지)인지 검사
     * @param context
     * @param packageName
     * @return
     */
    public static boolean isExistApp(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
        } catch (Exception e){
            return false;
        }
        return true;
    }

    /**
     * 어플 실행 상태 체크
     * @param context
     * @return
     */
    public static boolean checkIsAppRun(Context context) {
        boolean isRun = false;

        ActivityManager activity_manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> task_info = activity_manager.getRunningTasks(1);
        for(int i=0; i<task_info.size(); i++) {
            if(task_info.get(i).topActivity.getPackageName().equals("com.inplusweb.wbox")) {
                isRun = true;
            }
        }

        return isRun;
    }

    /**
     * 화면 상태 체크
     * @param context
     * @return
     */
    public static boolean checkIsScreenOn(Context context) {
        boolean isOn = false;

        if(sdkInt < Build.VERSION_CODES.KITKAT_WATCH) {
            // KITKAT 이하
            PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if(powerManager.isScreenOn()){
                isOn = true;
            }
        } else if (sdkInt >= Build.VERSION_CODES.KITKAT_WATCH) {
            // KITKAT 이상
            DisplayManager dm = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
            for(Display display : dm.getDisplays()) {
                if(display.getState() != Display.STATE_OFF) {
                    isOn = true;
                }
            }
        }

        return isOn;
    }

    /**
     * 네트워크 상태 체크
     * @param context
     * @return
     */
    public static int checkIsOnline(Context context) {

        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo.State wifiInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
            if(wifiInfo == NetworkInfo.State.CONNECTED || wifiInfo == NetworkInfo.State.CONNECTING) {
                return 2;
            }

            NetworkInfo.State mobileInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState();
            if(mobileInfo == NetworkInfo.State.CONNECTED || mobileInfo == NetworkInfo.State.CONNECTING) {
                return 1;
            }
        } catch (NullPointerException e) {
            return 0;
        }

        return 0;
    }

    /**
     * 휴대폰 번호 추출
     * @param context
     * @return
     */
    public static String getPhoneNo(Context context) {
        TelephonyManager telManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String phoneNo = telManager.getLine1Number();

        return phoneNo;
    }

    public static String getCountRun(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String cntRun = prefs.getString(COUNT_RUN, "");
        if(cntRun == "") {
            cntRun = "0";
        }

        int intCntRun = Integer.parseInt(cntRun);
        intCntRun++;
        cntRun = String.valueOf(intCntRun);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(COUNT_RUN, cntRun);
        editor.apply();

        return cntRun;
    }

    /**
     * 회원 아이디 저장
     * @param context
     * @param memberId
     */
    public static void storeMemberId(Context context, String memberId) {
        Log.d(TAG, "memberId : " + memberId);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(MEMBER_ID, memberId);
        editor.apply();
    }

    /**
     * 회원 아이디 추출
     * @param context
     * @return
     */
    public static String getMemberId(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String memberId = prefs.getString(MEMBER_ID, "");

        return memberId;
    }

    /**
     * GPS 환경설정 액티비티 이동
     * @param context
     */
    public static void moveConfigGps(Context context) {
        Intent gpsOptionsIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        context.startActivity(gpsOptionsIntent);
    }

    /**
     * 파일 첨부창 열기
     * @param context
     * @param requestCode
     */
    public static void openFileChooser(final Context context, final String requestCode) {

        openGallery(context, requestCode);

        /*
        mCustomDialog = new CustomDialog(context);
        mCustomDialog.setTitle("사진 선택");
        mCustomDialog.setPositiveButton("갤러리",
                new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        openGallery(context, requestCode);
                        mCustomDialog.dismiss();
                    }
                });

        mCustomDialog.setNegativeButton("카메라",
                new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        openCamera(context, requestCode);
                        mCustomDialog.dismiss();
                    }
                });

        mCustomDialog.show();
        */
    }

    /**
     * 갤러리 열기
     * @param context
     * @param strRequestCode
     */
    public static void openGallery(Context context, String strRequestCode) {

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.addCategory((Intent.CATEGORY_OPENABLE));

        int requestCode = Integer.parseInt(strRequestCode);
        ((MainActivity) context).startActivityForResult(Intent.createChooser(intent, "사진 선택"), requestCode);

        /*
        Intent intent = new Intent(Intent.ACTION_PICK);
        //intent.setType("image/*");
        intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);

        int requestCode = Integer.parseInt(strRequestCode);
        ((MainActivity) context).startActivityForResult(Intent.createChooser(intent, "사진 선택"), requestCode);
        */
    }

    /**
     * 카메라 열기
     * @param context
     * @param strRequestCode
     */
    public static void openCamera(Context context, String strRequestCode) {

        File directory = new File(DIRECTORY_PATH + File.separator + "photo");
        if(!directory.exists()) {
            directory.mkdir();
        }
        File mTempFile = new File(directory, "photo_" + new Date().getTime() + ".jpg");

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mTempFile));

        int requestCode = Integer.parseInt(strRequestCode);
        ((MainActivity)context).startActivityForResult(intent, requestCode);
    }

    /**
     * 파일 업로드
     * @param context
     * @param uploadUrl
     * @param fileUri
     * @throws IOException
     */
    public static void uploadFile(final Context context, final String uploadUrl, final Uri fileUri) {

        String memberId = CommonUtilities.getMemberId(context);
        String phoneNo = CommonUtilities.getPhoneNo(context);
        String deviseOs = "android";
        String regId = RegistrationIdManager.getRegistrationId();

        RequestParams params = new RequestParams();
        params.put("login_id", memberId);
        params.put("login_hp", phoneNo);
        params.put("mb_push_os", deviseOs);
        params.put("mb_push_id", regId);

        String filePath = getFilePath(context, fileUri);
        File file = new File(filePath);
        String pf_id = MainActivity.pf_id;
        String photoId = MainActivity.photoId;

        if(photoId.equals("main_img")){
            photoId = "main";
        }else if(photoId.equals("sub_img1")){
            photoId = "sub";
        }else if(photoId.equals("sub_img2")){
            photoId = "sub";
        }else if(photoId.equals("sub_img3")){
            photoId = "sub";
        }else if(photoId.equals("sub_img4")){
            photoId = "sub";
        }

        params.put("uid", pf_id);
        params.put("file_type[]", photoId);
        try {
            params.put("wr_file[]", file);
        } catch(FileNotFoundException e) {}


        final AsyncHttpClient client = new AsyncHttpClient();
        client.post(uploadUrl, params, new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                        Log.v(TAG, "Success");
                        String file_number= new String(responseBody);
                        MainActivity.callJavascript("changeFileId('"+MainActivity.photoId+"','"+file_number+"')");
                        // 파일 삭제
                        String filePath = CommonUtilities.getFilePath(MainActivity.context,fileUri);
                        File file = new File(filePath);
                        file.delete();
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                        Log.v(TAG, "Failure");
                    }
                }
        );


        /*new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {

                Log.v(TAG, "uploadUrl : " + uploadUrl);

                String filePath = getFilePath(context, fileUri);
                File file = new File(filePath);
                String fileType = getMimeType(context, fileUri);
                String regId = CommonUtilities.getMemberId(context);

                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBuilder()
                        .type(MultipartBuilder.FORM)
                        .addFormDataPart("mb_id", regId)
                        .addFormDataPart("wr_file[]", file.getName(),
                                RequestBody.create(MediaType.parse(fileType), file))
                        .build();

                Request request = new Request.Builder()
                        .url(uploadUrl)
                        .post(requestBody)
                        .build();

                Response response = null;
                try {
                    response = client.newCall(request).execute();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (!response.isSuccessful()) try {
                    throw new IOException("Unexpected code " + response);
                } catch (IOException e) {
                    e.printStackTrace();
                }




                return null;
            }
        }.execute();*/
    }

    /**
     * 위치 저장
     * @param context
     * @param flagArea
     */
    public static void storeFlagArea(Context context, String flagArea) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("flagArea", flagArea);
        editor.apply();
    }

    /**
     * 파일 타입 추출
     * @param context
     * @param uri
     * @return
     */
    public static String getMimeType(Context context, Uri uri) {
        ContentResolver cR = context.getContentResolver();
        //MimeTypeMap mime = MimeTypeMap.getSingleton();
        String type = cR.getType(uri);
        return type;
    }

    /**
     * 파일 경로 추출
     * @param context
     * @param uri
     * @return
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String getFilePath(Context context, Uri uri) {

        String filePath = "";
        if(uri.getPath().contains(":")) {
            String wholeID = DocumentsContract.getDocumentId(uri);

            // Split at colon, use second item in the array
            String id = wholeID.split(":")[1];

            String[] column = { MediaStore.Images.Media.DATA };

            // where id is equal to
            String sel = MediaStore.Images.Media._ID + "=?";

            Cursor cursor = context.getContentResolver().
                    query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            column, sel, new String[]{ id }, null);


            int columnIndex = cursor.getColumnIndex(column[0]);

            if(cursor.moveToFirst()) {
                filePath = cursor.getString(columnIndex);
            }

            cursor.close();
        }
        else {
            String id = uri.getLastPathSegment();
            final String[] imageColumns = {MediaStore.Images.Media.DATA };
            final String imageOrderBy = null;

            String selectedImagePath = "path";
            String scheme = uri.getScheme();
            if(scheme.equalsIgnoreCase("content")) {
                Cursor imageCursor = context.getContentResolver().query(uri, imageColumns, null, null, null);

                if(imageCursor.moveToFirst()) {
                    filePath = imageCursor.getString(imageCursor.getColumnIndex(MediaStore.Images.Media.DATA));
                }
            }
            else {
                filePath = uri.getPath();
            }
        }

        return filePath;
    }

    /**
     * 파일명 추출
     * @param context
     * @param uri
     * @return
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String getFileName(Context context, Uri uri) {

        String filePath = getFilePath(context, uri);
        File file = new File(filePath);
        String fileName = file.getName();

        return fileName;
    }

    /**
     * 파일을 문자열로 변환
     * @param context
     * @param fileUri
     * @return
     */
    public static String getFileContent(Context context, Uri fileUri) {

        String filePath = getFilePath(context, fileUri);
        File file = new File(filePath);

        String fileString = new String();
        FileInputStream inputStream = null;
        ByteArrayOutputStream byteOutStream = null;

        try {
            inputStream = new FileInputStream(file);
            byteOutStream = new ByteArrayOutputStream();

            int len = 0;
            byte[] buf = new byte[1024];
            while ((len = inputStream.read(buf)) != -1) {
                byteOutStream.write(buf, 0, len);
            }

            byte[] fileArray = byteOutStream.toByteArray();
            fileString = new String(Base64.encodeToString(fileArray, Base64.NO_WRAP));

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
                byteOutStream.close();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        return fileString;
    }

    /**
     * 임시 파일 저장 경로 생성
     * @return
     */
    public static Uri getTempFileUri() {
        Uri uri;
        String url = "tmp_" + String.valueOf(System.currentTimeMillis()) + ".jpg";
        uri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(), url));
        return uri;
    }

    /**
     * 푸시 사용 여부 저장
     * @param context
     * @param flagUsePush
     */
    public static void storeFlagUsePush(Context context, String flagUsePush) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(FLAG_USE_PUSH, flagUsePush);
        editor.apply();
    }

    /**
     * 푸시 사용 여부 조회
     * @param context
     * @return
     */
    public static String getFlagUsePush(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String flagUsePush = prefs.getString(FLAG_USE_PUSH, "");

        return flagUsePush;
    }

    /**
     * 전송을 통한 공유
     * @param context
     * @param send_info
     * @return
     */
    public static void shareBySend(Context context, String send_info) {

        Intent sendPageIntent = new Intent(Intent.ACTION_SEND);
        sendPageIntent.addCategory(Intent.CATEGORY_DEFAULT);
        sendPageIntent.putExtra(Intent.EXTRA_TEXT, send_info);
        sendPageIntent.setType("text/plain");
        context.startActivity(Intent.createChooser(sendPageIntent, "공유하기"));
    }
}
