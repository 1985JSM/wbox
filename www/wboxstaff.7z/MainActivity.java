package com.inplusweb.wboxstaff;

import android.*;
import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.MailTo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Created by MYM on 2015-08-20.
 * 메인 액티비티 클래스
 */
public class MainActivity extends Activity {

    // init
    private static final String TAG = "MainActivity";
    public static Context context;

    // 웹뷰
    public static WebView webviewMain;
    private WebSettings webSettingMain;
    public static ProgressBar progressbarMain;
    private CustomDialog mCustomDialog;

    public final static int FILE_FROM_PROFILE   = 10001; // 프로필 사진 선택
    public final static int CROP_FROM_PROFILE   = 10002; // 프로필 사진 크롭
    public final static int CROP_UPLOAD_PROFILE   = 10003; // 프로필 사진 업로드

    public final static int FILE_FROM_PORTFOLIO = 20001; // 포트폴리오 사진 선택
    public final static int CROP_FROM_PORTFOLIO = 20002; // 포트폴리오 사진 크롭
    public final static int CROP_UPLOAD_PORTFOLIO = 20003; // 포트폴리오 사진 업로드

    public static boolean flagFirst = true;

    private String fileName;
    private int cropRequestCode;
    public static String pf_id;
    public static String photoId;

    // KITKAT
    public static final String INTENT_PROTOCOL_START = "intent:";
    public static final String INTENT_PROTOCOL_INTENT = "#Intent;";
    public static final String INTENT_PROTOCOL_END = ";end;";
    public static final String GOOGLE_PLAY_STORE_PREFIX = "market://details?id=";

    // 뒤로가기 버튼으로 종료
    public static BackPressCloseHandler backPressCloseHandler;

    /**
     * 엑티비티 호출 시 실행
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 네트워크 상태 확인
        if(CommonUtilities.checkIsOnline(this) > 0) {

            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                startAppWithPermission();
            }
            else {
                // 퍼미션 리스너
                PermissionListener permissionListener = new PermissionListener() {
                    @Override
                    public void onPermissionGranted() {
                        startAppWithPermission();
                    }

                    @Override
                    public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                        Toast.makeText(MainActivity.this, getResources().getString(R.string.permission_error_msg), Toast.LENGTH_SHORT).show();
                        finish();
                    }
                };

                new TedPermission(this)
                        .setPermissionListener(permissionListener)
                        .setPermissions(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_PHONE_STATE, android.Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .check();
            }
        }
        else {
            mCustomDialog = new CustomDialog(this);
            mCustomDialog.setTitle(getResources().getString(R.string.app_name));
            mCustomDialog.setContent(getResources().getString(R.string.network_error_msg));

            mCustomDialog.setCloseButton(
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            mCustomDialog.dismiss();
                            finish();
                        }
                    });

            mCustomDialog.setPositiveButton("확인",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            mCustomDialog.dismiss();
                            finish();
                        }
                    });

            mCustomDialog.show();
        }
    }

    /**
     * 퍼미션 체크 후 웹뷰 실행
     */
    protected void startAppWithPermission() {

        // Context
        context = getApplicationContext();

        // 처음 실행된다면 스플래시 출력
        if(flagFirst) {
            setContentView(R.layout.activity_splash);
            startActivity(new Intent(MainActivity.this, SplashActivity.class));
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    setContentView(R.layout.activity_main);
                    runWebView();
                    flagFirst = false;
                }
            }, 0);
        }
        else {
            setContentView(R.layout.activity_main);
            runWebView();
        }

        // RegistrationId
        RegistrationIdManager.run(this);

        // 뒤로가기 버튼으로 종료
        backPressCloseHandler = new BackPressCloseHandler(this);
    }

    /**
     * 웹뷰 초기화
     */
    protected void runWebView() {
        webviewMain = (WebView) findViewById(R.id.webview_main);
        webviewMain.clearCache(true);

        // 웹뷰 기능 설정
        webSettingMain = webviewMain.getSettings();
        webSettingMain.setJavaScriptEnabled(true);
        webSettingMain.setPluginState(PluginState.ON_DEMAND);
        webSettingMain.setSupportZoom(false);
        webSettingMain.setBuiltInZoomControls(true);
        webSettingMain.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webSettingMain.setUseWideViewPort(true);
        webSettingMain.setLoadsImagesAutomatically(true);
        webSettingMain.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettingMain.setDomStorageEnabled(true);
        webSettingMain.setSupportMultipleWindows(true);
        webSettingMain.setGeolocationDatabasePath(getFilesDir().getPath());
        webSettingMain.setGeolocationEnabled(true);
        webSettingMain.setSaveFormData(true);

        // 웹뷰로 실행여부 체크 (useragent 수정)
        StringBuffer userAgent = new StringBuffer(webSettingMain.getUserAgentString());
        userAgent.append(";" + "WEBVIEW");
        webSettingMain.setUserAgentString((userAgent.toString()));

        webviewMain.setWebViewClient(new MyWebViewClient());
        webviewMain.setWebChromeClient(new MyWebChromeClient());

        // 환경설정 파일에 로그인 아이디 있다면 강제 로그인
        String memberId = CommonUtilities.getMemberId(this);
        String phoneNo = CommonUtilities.getPhoneNo(this);
        Log.d(TAG, "memberId : " + memberId);

        // Load URL
        String loadUrl = getResources().getString(R.string.member_process_url);
        String deviceOs = "android";
        String regId = RegistrationIdManager.getRegistrationId();
        Log.i(TAG, "regId : " + regId);
        loadUrl += "?mode=login_from_app&login_id=" + memberId + "&login_hp=" + phoneNo + "&mb_push_os=" + deviceOs + "&mb_push_id=" + regId;

        // 어플 실행횟수
        String cntRun = CommonUtilities.getCountRun(this);
        loadUrl += "&cnt_run=" + cntRun;

        // 푸시를 통해서 접근한 경우
        String pushUrl = getIntent().getStringExtra("pushUrl");
        Log.d(TAG, "pushUrl : " + pushUrl);
        if(pushUrl != null && !pushUrl.equals("")) {
            loadUrl += "&return_url=" + URLEncoder.encode(pushUrl);
        }
        Log.d(TAG, "loadUrl : " + loadUrl);

        webviewMain.loadUrl(getResources().getString(R.string.http_host) + loadUrl);
    }

    /**
     * 웹뷰 > 자바스크립트 호출
     */
    public static void callJavascript(String jsFunction) {
        Log.d(TAG, "jsFunction : " + jsFunction);
        webviewMain.loadUrl("javascript:" + jsFunction);
    }

    /**
     * 웹뷰 커스텀 (페이지 호출)
     */
    class MyWebViewClient extends WebViewClient {

        /**
         * 페이지 로딩 시작
         * @param view
         * @param url
         * @param favicon
         */
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            CommonUtilities.showProgressbar(MainActivity.this);
        }

        /**
         * 페이지 로딩 완료
         * @param view
         * @param url
         */
        @Override
        public void onPageFinished(WebView view, String url) {
            view.clearCache(true);
            super.onPageFinished(view, url);
            CommonUtilities.hideProgressbar(MainActivity.this);
        }

        /**
         * 인증 요청
         * @param view
         * @param handler
         * @param host
         * @param realm
         */
        @Override
        public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
            super.onReceivedHttpAuthRequest(view, handler, host, realm);
        }

        /**
         * 새로운 URL 호출(링크 클릭)
         * - 안드로이드 4.4부터는 웹뷰 엔진이 변경되어 처리를 다르게 해야 함
         * @param view
         * @param url
         * @return
         */
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            if(url.startsWith("native:")) {
                // 네이티브 브릿지
                NativeBridge.run(MainActivity.this, MainActivity.webviewMain, url);
                return true;
            }
            else if(CommonUtilities.checkIsOnline(MainActivity.this) > 0) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
                    // KITKAT이 아닐 때
                    if (url.startsWith("tel:")) {
                        // 전화걸기
                        new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE);
                        Intent localIntent6 = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                        MainActivity.this.startActivity(localIntent6);
                        return true;
                    } else if (url.startsWith("mailto:")) {
                        // 이메일 발송
                        MailTo.parse(url);
                        Intent localIntent5 = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        localIntent5.addCategory(Intent.CATEGORY_BROWSABLE);
                        MainActivity.this.startActivity(localIntent5);
                        return true;
                    } else if (url.startsWith("sms:")) {
                        // SMS 발송
                        new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE);
                        Intent localIntent7 = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
                        MainActivity.this.startActivity(localIntent7);
                        return true;
                    } else if (url.startsWith("kakaolink:")) {
                        // 카카오링크
                        try {
                            Intent localIntent1 = new Intent(Intent.ACTION_VIEW);
                            localIntent1.setData(Uri.parse(url));
                            MainActivity.this.startActivity(localIntent1);
                            return true;
                        } catch (ActivityNotFoundException e) {
                            return false;
                        }
                    } else if (url.startsWith("market:")) {
                        // 플레이스토어
                        if (CommonUtilities.isExistApp(MainActivity.this, "com.kakao.talk")) {
                            view.stopLoading();
                        } else {
                            Intent localIntent1 = new Intent(Intent.ACTION_VIEW);
                            localIntent1.setData(Uri.parse(url));
                            MainActivity.this.startActivity(localIntent1);
                            return true;
                        }
                    } else if (url.startsWith("storylink:")) {
                        // 카카오스토리
                        Intent localIntent2 = new Intent(Intent.ACTION_VIEW);
                        localIntent2.setData(Uri.parse(url));
                        MainActivity.this.startActivity(localIntent2);
                        return true;
                    } else {
                        if ((url.contains(".video")) || (url.contains(".mp4")) || (url.contains(".avi")) || (url.contains(".mpeg"))) {
                            // 동영상
                            Intent localIntent4 = new Intent(Intent.ACTION_VIEW);
                            localIntent4.setDataAndType(Uri.parse(url), "video/mp4");
                            MainActivity.this.startActivity(localIntent4);
                        }
                    }
                    return super.shouldOverrideUrlLoading(view, url);
                } else {
                    // KITKAT 이상일 때
                    if (url.startsWith("tel:")) {
                        // 전화걸기
                        new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE);
                        Intent localIntent6 = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                        MainActivity.this.startActivity(localIntent6);
                        return true;
                    } else if (url.startsWith("mailto:")) {
                        // 이메일 발송
                        MailTo.parse(url);
                        Intent localIntent5 = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        localIntent5.addCategory(Intent.CATEGORY_BROWSABLE);
                        MainActivity.this.startActivity(localIntent5);
                        return true;
                    } else if (url.startsWith("sms:")) {
                        // SMS 발송
                        new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE);
                        Intent localIntent7 = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
                        MainActivity.this.startActivity(localIntent7);
                        return true;
                    } else if (url.startsWith(INTENT_PROTOCOL_START)) {
                        // 기타 URL
                        final int customUrlStartIndex = INTENT_PROTOCOL_START.length();
                        final int customUrlEndIndex = url.indexOf(INTENT_PROTOCOL_INTENT);
                        if (customUrlEndIndex < 0) {
                            return false;
                        } else {
                            final String customUrl = url.substring(customUrlStartIndex, customUrlEndIndex);
                            try {
                                MainActivity.this.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(customUrl)));
                            } catch (ActivityNotFoundException e) {
                                final int packageStartIndex = customUrlEndIndex + INTENT_PROTOCOL_INTENT.length();
                                final int packageEndIndex = url.indexOf(INTENT_PROTOCOL_END);

                                final String packageName = url.substring(packageStartIndex, packageEndIndex < 0 ? url.length() : packageEndIndex);
                                MainActivity.this.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(GOOGLE_PLAY_STORE_PREFIX + packageName)));
                            }
                            return true;
                        }
                    } else {
                        if ((url.contains(".video")) || (url.contains(".mp4")) || (url.contains(".avi")) || (url.contains(".mpeg"))) {
                            Intent localIntent4 = new Intent(Intent.ACTION_VIEW);
                            localIntent4.setDataAndType(Uri.parse(url), "video/mp4");
                            MainActivity.this.startActivity(localIntent4);
                        }
                    }
                    return super.shouldOverrideUrlLoading(view, url);
                }
            }
            else {
                mCustomDialog = new CustomDialog(view.getContext());
                mCustomDialog.setTitle(getResources().getString(R.string.app_name));
                mCustomDialog.setContent(getResources().getString(R.string.network_error_msg));

                mCustomDialog.setCloseButton(
                        new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                mCustomDialog.dismiss();
                            }
                        });

                mCustomDialog.setPositiveButton("확인",
                        new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                mCustomDialog.dismiss();
                            }
                        });

                mCustomDialog.show();

                return true;
            }
        }

        /**
         * 에러 발생
         * @param view
         * @param errorCode
         * @param description
         * @param failingUrl
         */
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

            super.onReceivedError(view, errorCode, description, failingUrl);

            webviewMain.loadUrl(getResources().getString(R.string.network_error_url));
        }
    }

    /**
     * 웹뷰 커스텀 (페이지내 변화/알림)
     */
    class MyWebChromeClient extends WebChromeClient {

        /**
         * 윈도우 생성
         * @param view
         * @param dialog
         * @param userGesture
         * @param resultMsg
         * @return
         */
        @Override
        public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, Message resultMsg) {
            WebView newWebView = new WebView(view.getContext());
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(newWebView);
            resultMsg.sendToTarget();
            return true;
        }

        /**
         * 자바스크립트 경고창
         * @param view
         * @param url
         * @param message
         * @param result
         * @return
         */
        @Override
        public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {

            mCustomDialog = new CustomDialog(view.getContext());
            mCustomDialog.setTitle("알림");
            mCustomDialog.setContent(message);

            mCustomDialog.setCloseButton(
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            result.cancel();
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.setPositiveButton("확인",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            result.confirm();
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.show();

            return true;
        }

        /**
         * 자바스크립트 확인창
         * @param view
         * @param url
         * @param message
         * @param result
         * @return
         */
        @Override
        public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
            mCustomDialog = new CustomDialog(view.getContext());
            mCustomDialog.setTitle("알림");
            mCustomDialog.setContent(message);

            mCustomDialog.setCloseButton(
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            result.cancel();
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.setPositiveButton("확인",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            result.confirm();
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.setNegativeButton("취소",
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            result.cancel();
                            mCustomDialog.dismiss();
                        }
                    });

            mCustomDialog.show();

            return true;
        }

        /**
         * 위치정보 권한 요청
         * @param origin
         * @param callback
         */
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {

            // confirm 하지 않고 자동으로 허용
            callback.invoke(origin, true, false);
        }
    }

    /**
     * 뒤로가기 버튼 클릭
     */
    public void onBackPressed() {
        callJavascript("triggerBackButton()");
    }

    /**
     * 액티비티에 돌아왔을 때
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK) {

            if(requestCode == FILE_FROM_PROFILE) {

                // 프로필 사진 선택 후 크롭
                cropRequestCode = CROP_FROM_PROFILE;

                Uri fileUri = data.getData();
                fileName = CommonUtilities.getFileName(this, fileUri);
                UCrop uCrop = UCrop.of(fileUri, CommonUtilities.getTempFileUri());
                uCrop.withAspectRatio(32, 19).start(this);
            }
            else if(requestCode == FILE_FROM_PORTFOLIO) {

                // 포트폴리오 사진 선택 후 크롭
                cropRequestCode = CROP_FROM_PORTFOLIO;

                Uri fileUri = data.getData();
                fileName = CommonUtilities.getFileName(this, fileUri);
                UCrop uCrop = UCrop.of(fileUri, CommonUtilities.getTempFileUri());
                uCrop.withAspectRatio(32, 19).start(this);
            }
            else if(requestCode == UCrop.REQUEST_CROP) {

                // 크롭 후 전송
                final Uri resultUri = UCrop.getOutput((Intent) data);
                String fileContent = CommonUtilities.getFileContent(this, resultUri);
                Log.v(TAG, "fileContent : " + fileContent);
                String uploadUri = getResources().getString(R.string.http_host);

                if(cropRequestCode == CROP_FROM_PROFILE) {

                    // 프로필 사진 크롭 후 전송
                    //CommonUtilities.showProgressbar(this);
                    callJavascript("changeProfilePhoto('" + fileName + "', '" + fileContent + "')");
                    CommonUtilities.uploadFile(this, uploadUri + getResources().getString(R.string.profile_upload_url), resultUri);
                }
                else if(cropRequestCode == CROP_FROM_PORTFOLIO) {
                    Log.i(TAG,"photoId : "+photoId);

                    // 포트폴리오 사진 크롭 후 전송
                    callJavascript("changePortfolioPhoto('" + photoId + "', '" + fileName + "', '" + fileContent + "')");
                    CommonUtilities.uploadFile(this, uploadUri + getResources().getString(R.string.portfolio_upload_url), resultUri);
                }

                else if(cropRequestCode == CROP_UPLOAD_PROFILE) {
                    Log.i(TAG,"photoId : "+photoId);

                    // 포트폴리오 사진 크롭 후 전송
                    callJavascript("changePortfolioPhoto('" + photoId + "', '" + fileName + "', '" + fileContent + "')");
                    CommonUtilities.uploadFile(this, uploadUri + getResources().getString(R.string.portfolio_upload_url), resultUri);
                }

                else if(cropRequestCode == CROP_UPLOAD_PORTFOLIO) {
                    Log.i(TAG,"photoId : "+photoId);

                    // 포트폴리오 사진 크롭 후 전송
                    callJavascript("changePortfolioPhoto('" + photoId + "', '" + fileName + "', '" + fileContent + "')");
                    CommonUtilities.uploadFile(this, uploadUri + getResources().getString(R.string.portfolio_upload_url), resultUri);
                }
                // 파일 삭제
                //String filePath = CommonUtilities.getFilePath(this, resultUri);
                //File file = new File(filePath);
                // file.delete();
            }

        }

        Log.v(TAG, "requestCode : " + requestCode);
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v(TAG, "onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v(TAG, "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TAG, "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v(TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy");
    }
}
